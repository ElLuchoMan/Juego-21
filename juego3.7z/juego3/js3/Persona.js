function Persona() {
    this.x = 55;
    this.y = 397;
    this.img = [$("#arriba")[0], $("#abajo")[0], $("#golpe")[0], $("#der1")[0],$("#der2")[0],$("#der3")[0],$("#der4")[0]
                , $("#izq1")[0],$("#izq2")[0],$("#izq3")[0],$("#izq4")[0]];
    this.sprite = 0;
    this.vida = 10;
    this.puntos = 0;
    this.pasod = 0;
    this.pasoi = 0;

    this.dibujar = function (ctx) {
        var img = this.img[this.sprite];
        var x = this.x;
        var y = this.y;
        ctx.drawImage(img, x, y);
        ctx.save();
        ctx.fillStyle = "#ffffff";
        ctx.font = "15px sans-serif";
        ctx.fillText("Puntos: " + this.puntos, 10, 15);
        ctx.fillText("Vida: " + this.vida, 10, 30);
        ctx.restore();
    }

    this.actualizar = function (accion) {
        if (accion == "arriba" && this.y > 5) {
            this.y -= 10;
            this.sprite = 0;
        }
        if (accion == "abajo" && this.y < 427) {
            this.y += 10;
            this.sprite = 1;
        }

        if (accion == "izquierda" && this.x > 3) {
            switch (this.pasoi) {
                case 0:
                    this.sprite = 7;
                    this.pasoi = 1;
                    break;
                case 1:
                    this.sprite = 8;
                    this.pasoi = 2;
                    break;
                case 2:
                    this.sprite = 9;
                    this.pasoi = 3;
                    break;
                case 3:
                    this.sprite = 10;
                    this.pasoi = 0;
                    break;
            }
            this.x -= 10;
        }
        if (accion == "derecha" && this.x < 880) {
            switch (this.pasod) {
                case 0:
                    this.sprite = 3;
                    this.pasod = 1;
                    break;
                case 1:
                    this.sprite = 4;
                    this.pasod = 2;
                    break;
                case 2:
                    this.sprite = 5;
                    this.pasod = 3;
                    break;
                case 3:
                    this.sprite = 6;
                    this.pasod = 0;
                    break;
            }
            this.x += 10;
        }
    }

    var plataforma = function (x, y, ancho, alto) {
        var y = y;
        var x = x;
        return{x: x, y: y}
    };

    this.colision = function (x, y) {
        var distancia = Math.sqrt(Math.pow((x - this.x), 2) + Math.pow((y - this.y), 2));
        if (distancia > this.img[this.sprite].width)
            return false;
        else
            return true;
    }
}