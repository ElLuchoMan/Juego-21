
$(document).ready(inicio);
$(document).keydown(manejar_evento);

function inicio() {
	lienzo = $("#lienzo")[0];
	contexto = lienzo.getContext("2d");
	buffer = document.createElement("canvas");
	donkey = new Donkey();
	barril = [new Barril(), new Barril(), new Barril()];
	animar();
}

function animar(){
	buffer.width = lienzo.width;
	buffer.height = lienzo.height;
	contextoBuffer = buffer.getContext("2d");
	
	contextoBuffer.clearRect(0, 0, buffer.width, buffer.height);
	donkey.dibujar(contextoBuffer);
	donkey.actualizarX();

	for (i = 0; i < barril.length; i++) {

		barril[i].dibujarB(contextoBuffer);
        barril[i].actualizarB();
        if(donkey.colision(barril[i].x,barril[i].y)){
        	alert("Game Over");
        	barril[i].y=-138;
        	barril[i].x=aleatorio(0,1080);
       }
	}

	contexto.clearRect(0, 0, lienzo.width, lienzo.height);
	contexto.drawImage(buffer, 0, 0);
	
	
	setTimeout("animar()", 20);
}

function manejar_evento(event){
	if (event.which == 39){
		donkey.actualizarX("derecha")
	}
	if (event.which == 37){
		donkey.actualizarX("izquierda")
	}
}
function aleatorio(piso, techo) {
    return Math.floor(Math.random() * (techo - piso + 1)) + piso;
}

function Barril (x,y){

	var opc = aleatorio(2, 100) % 2;
	this.img = $("#barril")[0];
	this.x = aleatorio(0, 1080);
    this.y = -138;
	

	this.dibujarB = function(ctx) {
		var img = this.img;
		ctx.drawImage(this.img, this.x, this.y);
	}
	
	this.actualizarB = function() {
		this.y +=7;
		if (this.y>600){
			this.x = aleatorio(0, 1080);
    		this.y = -138;
		}
	}
}

function Donkey(){
	this.x = 500;
	this.y = 450;
	this.vel=10;
	this.img = $("#donkey")[0];
	
	this.dibujar = function(ctx) {
		ctx.drawImage(this.img, this.x, this.y);
	}	
	
	
	this.actualizarX = function(accion) {
		if (accion == "derecha" && this.x + 205 <= lienzo.width ){
			this.x += this.vel;
		}
		if (accion == "izquierda" && this.x + 205 <= lienzo.width ){
			this.x -= this.vel;}		
	}
	 this.colision = function (x, y) {
        var distancia = (3/2)*Math.sqrt(Math.pow((x - this.x), 2) + Math.pow((y - this.y), 2))+20;
        if (distancia > this.img.width)
            return false;
        else
            return true;
    }
 }